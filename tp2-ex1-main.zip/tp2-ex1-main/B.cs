﻿namespace tp2_ex1
{
    class B : A
    {
        private int b1;

        public B(int a1, int a2, int a3, int b1) : base(a1, a2,a3)
        {
            this.b1 = b1;
        }

        public override int Somme()
        {
            return (a1 + a2 + a3 + b1);
        }

        public int Multiplication(C objc)
        {
            objc.a3 = a3 * a2;
            return objc.a3;
        }
    }
}
