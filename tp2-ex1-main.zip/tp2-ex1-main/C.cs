﻿namespace tp2_ex1
{
    class C : A
    {
        public C(int a1, int a2, int a3) : base(a1,a2, a3) { }

        public int Somme(int x)
        {
            return a3 + x;
        }

        public override int Somme()
        {
            return 0;
        }
    }
}
