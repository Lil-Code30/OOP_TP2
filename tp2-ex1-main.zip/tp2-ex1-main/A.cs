﻿namespace tp2_ex1
{
    abstract class A
    {
        protected int a1;
        protected int a2;
        public int a3;

        protected A(int a1, int a2, int a3)
        {
            this.a1 = a1;
            this.a2 = a2;
            this.a3 = a3;
        }

        abstract public int Somme();

        public virtual int Mutiplication(int y)
        {
            y = y * a1 * a2 * a3;
            return y;
        }

        public float Moyenne(int z)
        {
            return Somme() / z;
        }
    }
}
