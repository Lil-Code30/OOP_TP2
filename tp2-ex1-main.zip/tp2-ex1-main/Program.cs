﻿using tp2_ex1;

class Program
{
    static void Main()
    {
        //A obja = new A(10, 11, 12, 13);   ERREUR : A est abstraite, on ne peut pas l'instancier 
        B objb = new B(1, 2, 3, 4);     // CORRECT
        //C objc = new C(6, 7, 8, 9);    ERREUR : C attend 3 paramètres, pas 4 
        C objc = new C(6, 7, 8);  

        Console.WriteLine(objc.Somme(10));
        Console.WriteLine(objb.Moyenne(4));
        Console.WriteLine(objb.Multiplication(objc));
        //Console.WriteLine(objc.Multiplication(objc.a3));  Pas d’affichage
        //Console.Write(objb.Multiplication(objc.a3));   Pas d’affichage
        Console.WriteLine(objc.Moyenne(4));
        //Console.Write(objb.a2 + " " + objc.a2);    Pas d’affichage
        Console.WriteLine(objb.a3 + " " + objc.a3);
    }
}
